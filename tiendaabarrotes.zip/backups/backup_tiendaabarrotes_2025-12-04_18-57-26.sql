-- Respaldo de base de datos: tiendaabarrotes
-- Generado en: 2025-12-04 18:57:26

SET FOREIGN_KEY_CHECKS=0;

-- -------------------------------------------
-- Tabla: `auditoria`
-- -------------------------------------------

DROP TABLE IF EXISTS `auditoria`;
CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `accion` varchar(50) NOT NULL,
  `modulo` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `auditoria_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla `auditoria`
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('1', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso', '127.0.0.1', '2025-11-30 19:49:38');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('2', '1', 'CREAR', 'Usuarios', 'Usuario vendedor1 creado', '127.0.0.1', '2025-11-30 19:49:38');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('3', '1', 'CREAR', 'Proveedores', 'Proveedor Distribuidora Lima SAC registrado', '127.0.0.1', '2025-11-30 19:49:38');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('12', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin', '::1', '2025-11-30 20:54:20');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('13', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin', '::1', '2025-11-30 20:54:37');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('14', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin', '::1', '2025-11-30 20:54:54');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('15', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-11-30 21:07:06');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('16', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-11-30 22:06:41');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('17', '1', 'CREAR', 'Productos', 'Producto creado: duraznos (Código: PROD030)', '::1', '2025-11-30 22:17:40');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('18', '1', 'ELIMINAR', 'Productos', 'Producto eliminado: duraznos (ID: 11)', '::1', '2025-11-30 22:17:47');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('19', '1', 'ACTUALIZAR', 'Proveedores', 'Proveedor actualizado: Alimentos del Norte EIRL (ID: 2)', '::1', '2025-11-30 22:22:28');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('20', '1', 'CREAR', 'Proveedores', 'Proveedor creado: Alimentos del Norte EIRL (RUC: 12345678901)', '::1', '2025-11-30 22:23:08');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('21', '1', 'ELIMINAR', 'Proveedores', 'Proveedor eliminado: Alimentos del Norte EIRL (ID: 5)', '::1', '2025-11-30 22:23:13');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('22', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-11-30 22:31:36');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('23', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-11-30 23:08:38');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('24', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-11-30 23:08:53');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('25', '1', 'BACKUP', 'Respaldo', 'Respaldo creado (PHP): backup_tiendaabarrotes_2025-12-01_05-11-16.sql', '::1', '2025-11-30 23:11:16');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('26', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-11-30 23:22:45');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('27', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: proveedor', '::1', '2025-11-30 23:22:46');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('28', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-11-30 23:23:01');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('29', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-11-30 23:23:15');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('30', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: vendedor2', '::1', '2025-11-30 23:23:48');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('31', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-11-30 23:23:57');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('32', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-11-30 23:35:13');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('33', NULL, 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: camila', '::1', '2025-11-30 23:35:20');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('34', NULL, 'LOGOUT', 'Autenticación', 'Cierre de sesión: camila', '::1', '2025-11-30 23:35:23');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('35', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-01 20:45:48');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('36', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 03:26:04');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('37', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 03:32:04');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('39', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:06:52');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('40', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 12:06:53');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('41', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:07:34');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('42', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Arroz Superior 1kg (ID: 1)', '::1', '2025-12-04 12:09:20');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('43', '1', 'CREAR', 'Productos', 'Producto creado: Tallarín victorio (Código: PROD020)', '::1', '2025-12-04 12:11:42');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('44', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Tallarín victorio (ID: 12)', '::1', '2025-12-04 12:12:10');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('45', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Tallarín victorio (ID: 12)', '::1', '2025-12-04 12:12:28');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('46', '1', 'ELIMINAR', 'Productos', 'Producto eliminado: Frijol Canario 1kg (ID: 6)', '::1', '2025-12-04 12:12:49');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('47', '1', 'ELIMINAR', 'Productos', 'Producto eliminado: Arroz Superior 1kg (ID: 1)', '::1', '2025-12-04 12:13:45');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('48', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 12:15:08');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('49', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: jose', '::1', '2025-12-04 12:15:16');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('50', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:15:32');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('51', '1', 'ACTUALIZAR', 'Proveedores', 'Proveedor actualizado: pacasmayo (ID: 4)', '::1', '2025-12-04 12:18:23');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('52', '1', 'CREAR', 'Proveedores', 'Proveedor creado: pacasmayoIDE (RUC: 23456789234)', '::1', '2025-12-04 12:19:35');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('53', '1', 'BACKUP', 'Respaldo', 'Respaldo creado (PHP): backup_tiendaabarrotes_2025-12-04_18-23-31.sql', '::1', '2025-12-04 12:23:31');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('54', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Tallarín victorio (ID: 12)', '::1', '2025-12-04 12:25:06');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('55', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 12:26:03');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('56', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: proveedor', '::1', '2025-12-04 12:26:06');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('57', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: proveedor', '::1', '2025-12-04 12:26:30');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('58', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:26:40');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('59', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 12:27:12');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('60', '6', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: camila', '::1', '2025-12-04 12:27:19');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('61', '6', 'LOGOUT', 'Autenticación', 'Cierre de sesión: camila', '::1', '2025-12-04 12:27:21');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('62', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admina', '::1', '2025-12-04 12:28:12');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('63', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin1', '::1', '2025-12-04 12:28:20');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('64', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin1', '::1', '2025-12-04 12:28:25');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('65', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin1', '::1', '2025-12-04 12:28:30');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('66', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:28:34');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('67', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-12-04 12:29:59');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('68', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-12-04 12:30:16');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('69', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-12-04 12:30:30');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('70', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-12-04 12:30:48');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('71', '1', 'ELIMINAR', 'Productos', 'Producto eliminado: Aceite Vegetal 1L (ID: 2)', '::1', '2025-12-04 12:31:12');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('72', '1', 'CREAR', 'Productos', 'Producto creado: coca cola (Código: PROD015)', '::1', '2025-12-04 12:32:30');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('73', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 12:34:00');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('74', '6', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: camila', '::1', '2025-12-04 12:34:08');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('75', '6', 'LOGOUT', 'Autenticación', 'Cierre de sesión: camila', '::1', '2025-12-04 12:34:13');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('76', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:34:14');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('77', '1', 'ACTUALIZAR', 'Proveedores', 'Proveedor actualizado: pacasmayo (ID: 1)', '::1', '2025-12-04 12:35:05');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('78', '1', 'ELIMINAR', 'Proveedores', 'Proveedor eliminado: pacasmayoIDE (ID: 6)', '::1', '2025-12-04 12:35:56');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('79', '1', 'CREAR', 'Proveedores', 'Proveedor creado: faraon (RUC: 23456781234)', '::1', '2025-12-04 12:37:18');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('80', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 12:39:47');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('81', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin1', '::1', '2025-12-04 12:45:57');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('82', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin1', '::1', '2025-12-04 12:45:59');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('83', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin1', '::1', '2025-12-04 12:46:02');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('84', NULL, 'LOGIN_FALLIDO', 'Autenticación', 'Intento de inicio de sesión fallido para usuario: admin1', '::1', '2025-12-04 12:46:08');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('85', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:46:15');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('86', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-12-04 12:47:17');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('87', '1', 'ACTUALIZAR', 'Productos', 'Producto actualizado: Atún en Lata (ID: 7)', '::1', '2025-12-04 12:47:25');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('88', '1', 'CREAR', 'Productos', 'Producto creado: leche gloria (Código: PROD016)', '::1', '2025-12-04 12:48:46');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('89', '1', 'ELIMINAR', 'Productos', 'Producto eliminado: coca cola (ID: 14)', '::1', '2025-12-04 12:49:06');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('90', '1', 'LOGOUT', 'Autenticación', 'Cierre de sesión: admin', '::1', '2025-12-04 12:51:09');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('91', '6', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: camila', '::1', '2025-12-04 12:51:15');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('92', '6', 'ACTUALIZAR', 'Proveedores', 'Proveedor actualizado: CusiCousaUrb (ID: 1)', '::1', '2025-12-04 12:52:24');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('93', '6', 'CREAR', 'Proveedores', 'Proveedor creado: DeleiteIDe (RUC: 34567891234)', '::1', '2025-12-04 12:53:52');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('94', '6', 'ELIMINAR', 'Proveedores', 'Proveedor eliminado: faraon (ID: 8)', '::1', '2025-12-04 12:54:20');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('95', '6', 'LOGOUT', 'Autenticación', 'Cierre de sesión: camila', '::1', '2025-12-04 12:55:31');
INSERT INTO `auditoria` (`id`, `usuario_id`, `accion`, `modulo`, `descripcion`, `ip`, `fecha`) VALUES ('96', '1', 'LOGIN', 'Autenticación', 'Inicio de sesión exitoso: admin', '::1', '2025-12-04 12:55:32');

-- -------------------------------------------
-- Tabla: `productos`
-- -------------------------------------------

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) DEFAULT 10,
  `proveedor_id` int(11) DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `estado` tinyint(1) DEFAULT 1,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `proveedor_id` (`proveedor_id`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla `productos`
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('1', 'PROD001', 'Arroz Superior 1kg', 'Granos', '2.80', '3.50', '300', '30', '1', '2026-01-20', '0', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('2', 'PROD002', 'Aceite Vegetal 1L', 'Aceites', '6.50', '7.80', '80', '15', '1', NULL, '0', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('3', 'PROD003', 'Azúcar Blanca 1kg', 'Abarrotes', '2.30', '2.90', '200', '25', '2', NULL, '1', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('4', 'PROD004', 'Fideos Spaghetti', 'Pastas', '2.00', '2.50', '120', '20', '2', NULL, '1', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('5', 'PROD005', 'Leche Evaporada', 'Lácteos', '3.50', '4.20', '90', '15', '3', NULL, '1', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('6', 'PROD006', 'Frijol Canario 1kg', 'Granos', '4.80', '5.80', '75', '15', '1', NULL, '0', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('7', 'PROD007', 'Atún en Lata', 'Enlatados', '3.70', '3.60', '100', '20', '2', '2020-02-01', '1', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('8', 'PROD008', 'Detergente 1kg', 'Limpieza', '7.00', '8.50', '8', '10', '4', NULL, '1', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('9', 'PROD009', 'Galletas Soda', 'Snacks', '1.80', '2.20', '150', '25', '2', NULL, '1', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('10', 'PROD010', 'Sal de Mesa 1kg', 'Abarrotes', '0.80', '1.20', '5', '10', '1', NULL, '1', '2025-11-30 19:49:38');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('11', 'PROD030', 'duraznos', 'Lácteos', '30.00', '6.00', '50', '10', '2', '2024-03-20', '0', '2025-11-30 22:17:40');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('12', 'PROD020', 'Tallarín victorio', 'Pastas', '7.00', '150.00', '3', '100', '3', '2030-09-09', '1', '2025-12-04 12:11:42');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('14', 'PROD015', 'coca cola', 'Bebidas', '10.00', '100.00', '50', '16', '4', '2030-12-02', '0', '2025-12-04 12:32:30');
INSERT INTO `productos` (`id`, `codigo`, `nombre`, `categoria`, `precio_compra`, `precio_venta`, `stock`, `stock_minimo`, `proveedor_id`, `fecha_vencimiento`, `estado`, `fecha_registro`) VALUES ('15', 'PROD016', 'leche gloria', 'Lácteos', '50.00', '100.00', '50', '19', '2', '2027-01-24', '1', '2025-12-04 12:48:46');

-- -------------------------------------------
-- Tabla: `proveedores`
-- -------------------------------------------

DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ruc` varchar(11) NOT NULL,
  `razon_social` varchar(150) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT 1,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ruc` (`ruc`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla `proveedores`
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('1', '20123456789', 'CusiCousaUrb', 'Carlos Rodríguez', '987654321', 'ventas@distlima.com', 'Av. Colonial 123, Lima', '1', '2025-11-30 19:49:38');
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('2', '20987654321', 'Alimentos del Norte EIRL', 'Ana maria', '965432187', 'contacto@alinorte.com', 'Jr. Libertad 456, Trujillo', '1', '2025-11-30 19:49:38');
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('3', '20456789123', 'Productos Andinos SA', 'José Martinez', '954321876', 'info@proandinos.com', 'Av. Industrial 789, Arequipa', '1', '2025-11-30 19:49:38');
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('4', '20321654987', 'pacasmayo', 'Rosa Vega', '943218765', 'elsol@comercial.com', 'Calle Comercio 321, Cusco', '1', '2025-11-30 19:49:38');
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('5', '12345678901', 'Alimentos del Norte EIRL', 'juan gabriel', '997718444', 'arianaabregu235@gmail.com', 'ola', '0', '2025-11-30 22:23:08');
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('6', '23456789234', 'pacasmayoIDE', 'juan gabriel', '949827863', 'acevestancia21@gmail.com', 'el agustino', '0', '2025-12-04 12:19:35');
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('8', '23456781234', 'faraon', 'marisol', '123456789', 'abreguariana@gmail.com', 'la molina', '0', '2025-12-04 12:37:18');
INSERT INTO `proveedores` (`id`, `ruc`, `razon_social`, `contacto`, `telefono`, `email`, `direccion`, `estado`, `fecha_registro`) VALUES ('9', '34567891234', 'DeleiteIDe', 'elmer', '987654321', 'abreguariana@gmail.com', 'la molina', '1', '2025-12-04 12:53:52');

-- -------------------------------------------
-- Tabla: `usuarios`
-- -------------------------------------------

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `rol` enum('admin','vendedor') DEFAULT 'vendedor',
  `estado` tinyint(1) DEFAULT 1,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos de la tabla `usuarios`
INSERT INTO `usuarios` (`id`, `usuario`, `clave`, `nombre_completo`, `email`, `rol`, `estado`, `fecha_registro`) VALUES ('1', 'admin', '$2y$10$TEaPOkgHY8hsWjMv3s5ZSOmzLJtTvRbOKtNhkaeOg4a9XFAVmxZA6', 'Administrador Principal', 'admin@tienda.com', 'admin', '1', '2025-11-30 19:49:37');
INSERT INTO `usuarios` (`id`, `usuario`, `clave`, `nombre_completo`, `email`, `rol`, `estado`, `fecha_registro`) VALUES ('3', 'vendedor2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'María González', 'maria@tienda.com', 'vendedor', '1', '2025-11-30 19:49:37');
INSERT INTO `usuarios` (`id`, `usuario`, `clave`, `nombre_completo`, `email`, `rol`, `estado`, `fecha_registro`) VALUES ('6', 'camila', '$2y$10$lL3vxNrwWhHqD9O5N63J8OpEa3AVjS7STLhphrfaAP2ozZEIBNpvC', 'camila fernanda', NULL, 'vendedor', '1', '2025-12-04 12:27:09');
INSERT INTO `usuarios` (`id`, `usuario`, `clave`, `nombre_completo`, `email`, `rol`, `estado`, `fecha_registro`) VALUES ('8', 'ale', '$2y$10$AdC/oBTsFt.edaeszx5ypeo3odIvOghaOLi5QYQBgczxhLEdgDUM6', 'alessandro', NULL, 'admin', '1', '2025-12-04 12:50:35');

SET FOREIGN_KEY_CHECKS=1;
